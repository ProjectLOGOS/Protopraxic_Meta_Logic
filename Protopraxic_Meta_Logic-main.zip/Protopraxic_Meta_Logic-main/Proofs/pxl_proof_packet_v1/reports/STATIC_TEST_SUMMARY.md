# PXLv3 Static Test Summary
Generated: 2025-09-24T07:39:23

## Checks
- Symbol audit vs approved glyphs
- Classical operator leakage
- '≡' replacement with '⩪'
- Inventory of axioms, theorems, advanced theorems, paradoxes, resolutions
- Headings index and duplicate title scan

- Files scanned: **11**
- Files with disallowed tokens: **6**
- Files still using '≡': **0**
