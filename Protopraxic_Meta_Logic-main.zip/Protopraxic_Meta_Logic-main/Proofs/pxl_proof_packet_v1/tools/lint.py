#!/usr/bin/env python3
import sys, pathlib
root = pathlib.Path(__file__).resolve().parents[1]
print("Scanning", root)
sys.exit(0)
