# Phase 6 — Expressive Adequacy & Normalization

Negation Normal Form (NNF) for modal language, with semantic correctness.

Build:

  cd coq
  powershell -NoProfile -ExecutionPolicy Bypass -File .\meta-build.ps1 -Clean

Artifact: PXL_Normalization.vo
