﻿$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $(\System.Management.Automation.InvocationInfo.MyCommand.Path)
Set-Location $here

# Tools
$coqBin = "C:\Coq-Platform~8.20~2025.01\bin"
$coqStd = "C:\Coq-Platform~8.20~2025.01\lib\coq\theories"

# Build all .v in logical root
$vFiles = Get-ChildItem -Recurse .\coq -Filter *.v | Sort-Object FullName

# Compile
foreach ($f in $vFiles) {
  & (Join-Path $coqBin 'coqc.exe') -q -R "$coqStd" Coq -Q coq PXLs "$($f.FullName)"
}

# Kernel check (logical path root)
& (Join-Path $coqBin 'coqchk.exe') -silent -R coq PXLs

# Hygiene scan
$hits = @()
Get-ChildItem -Recurse .\coq -Filter *.v | ForEach-Object {
  $p = $\_.FullName
  (Get-Content $p) | Select-String -Pattern '^(Axiom|Admitted|Parameter)\b' | ForEach-Object {
    $hits += "$p:$($_.LineNumber): $($_.Line)"
  }
}
$hits | Set-Content -Encoding UTF8 .\hygiene.txt
Write-Host "Build + coqchk OK. Hygiene hits written to hygiene.txt"
