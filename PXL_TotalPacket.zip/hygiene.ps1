﻿Get-ChildItem -Recurse .\coq -Filter *.v | ForEach-Object {
  $p = $\_.FullName
  (Get-Content $p) | Select-String -Pattern '^(Axiom|Admitted|Parameter)\b' | ForEach-Object {
    "$p:$($_.LineNumber): $($_.Line)"
  }
} | Set-Content -Encoding UTF8 .\hygiene.txt
Write-Host "Hygiene hits written to hygiene.txt"
