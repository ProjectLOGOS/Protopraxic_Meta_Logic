# Phase 5 — Decidability & Complexity (Harness)

Propositional tautology checker and a placeholder bounded modal decision interface.
Build:

  cd coq
  powershell -NoProfile -ExecutionPolicy Bypass -File .\meta-build.ps1 -Clean

Artifact: PXL_Decidability.vo
