Write-Host "CI smoke OK"
