
PXLv3 Formal Skeleton
=====================

Contents
--------
- lean/src/PXLv3.lean  — Lean4 module with PXL operators, S5-style modal scaffolding, axioms, and stub theorems.
- coq/PXLv3.v          — Coq module with UTF-8 notations, axioms, and stub lemmas.
- This is a **scaffold**. Replace placeholder axioms with the approved PXLv3 axioms and semantics.

How to run (Lean4)
------------------
1) Install Lean4 (4.10+).
2) From `lean/`, create a basic Lake project if needed:
   - `lake init pxl_skeleton`
   - Move `src/PXLv3.lean` into the generated `pxl_skeleton/` project `./PXLv3.lean` or adjust paths.
   - Or add to an existing Lake project.
3) Build/typecheck:
   - `lake build`

How to run (Coq)
----------------
1) Install Coq (8.18+).
2) From `coq/`:
   - `coqc PXLv3.v`

Next steps for **validity**
---------------------------
- Encode each approved axiom as an `axiom` (Lean) / `Axiom` (Coq) or as `def` + theorems if constructive.
- Encode each inference rule either as a derived lemma or using a meta-rule surrogate.
- Replace `sorry`/`Admitted` with real proofs. Keep a checklist.

Next steps for **soundness**
----------------------------
- Provide a model: define structures interpreting ⧟, ⇎, ⇌ over `Obj` and □/◇ over `Prop`.
- Prove each inference rule is truth-preserving under that model.
- Example targets:
  - `sound_imp`: if `p ⟹ q` holds under model M and `p` is true in M, then `q` is true in M.
  - `sound_mequiv`: `p ⩪ q` iff `p` and `q` share truth in all admissible states.
  - S5 axioms are theorems of your modal semantics.

Files
-----
- Lean: lean/src/PXLv3.lean
- Coq:  coq/PXLv3.v
